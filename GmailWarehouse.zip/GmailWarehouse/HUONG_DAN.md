# Gmail Warehouse – Hướng dẫn

Ứng dụng Android (Kotlin, Jetpack Compose, Material 3, Room, Android Keystore, AES-256-GCM). Offline hoàn toàn, **không có quyền Internet**.

> Lưu ý: mã nguồn này chưa được biên dịch thử trong môi trường tạo ra nó (không có Android SDK). Lần build đầu có thể còn lỗi nhỏ. Nếu build lỗi, copy log lỗi gửi lại để sửa.

## 1. Lấy file APK (cách nhanh nhất: GitHub Actions, không cần cài gì)
1. Tạo tài khoản GitHub (miễn phí), tạo repository mới (Private cũng được).
2. Giải nén file zip trên máy tính, vào repo bấm **Add file → Upload files**, kéo toàn bộ nội dung thư mục `GmailWarehouse` vào (gồm cả thư mục ẩn `.github`), rồi **Commit**.
   - Nếu thư mục `.github` không được tải lên: bấm **Add file → Create new file**, gõ tên `.github/workflows/build.yml`, dán nội dung file `build.yml` trong zip, rồi Commit.
3. Mở tab **Actions** → workflow **Build APK** sẽ tự chạy (khoảng 5–10 phút). Nếu không chạy, bấm **Run workflow**.
4. Chạy xong, mở lần chạy đó, kéo xuống mục **Artifacts**, tải `GmailWarehouse-debug-apk` (giải nén ra `app-debug.apk`). Có thể có thêm `GmailWarehouse-release-apk`.

## 2. Mở bằng Android Studio (nếu muốn tự build)
- Cài Android Studio (bản mới), chọn **Open** thư mục dự án, đợi Gradle sync (dùng JDK 17).
- Build → Build APK(s). File ra ở `app/build/outputs/apk/debug/app-debug.apk`.
- Hoặc dòng lệnh: `./gradlew assembleDebug`.

## 3. Cài APK trên điện thoại (Xiaomi)
1. Chép `app-debug.apk` vào điện thoại, mở bằng Trình quản lý tệp.
2. Cho phép "Cài đặt ứng dụng không rõ nguồn" nếu máy hỏi; nếu MIUI chặn, vào Cài đặt → Quyền riêng tư → Quyền đặc biệt → Cài đặt ứng dụng không rõ nguồn.
3. Mở **Gmail Warehouse**, lần đầu tạo **mật khẩu kho** (tối thiểu 6 ký tự). Quên mật khẩu kho sẽ không mở được dữ liệu, hãy sao lưu thường xuyên.

## 4. Cách dùng nhanh
- **Máy ảo**: tab "Máy ảo" → "Tạo hàng loạt" (VD: tiền tố `VIP-`, từ 1, số lượng 7). Cần thêm thì tạo tiếp (tối đa 1000 mỗi lần, không giới hạn tổng).
- **Thêm Gmail**: chọn trạng thái "Đang dùng", nhập tên máy ảo và số ngày/giờ còn lại của máy ảo.
- **Liên kết**: ở tab "Máy ảo" bấm "Liên kết Gmail". Một Gmail đã gắn máy ảo khác chỉ liên kết thêm khi tick "cho phép dùng chung".
- Chuyển sang "Chưa dùng" / "Bị ban" sẽ tự gỡ Gmail khỏi máy ảo.
- Sao chép mật khẩu: clipboard tự xóa sau 60 giây (bật/tắt trong Cài đặt).

## 5. Sao lưu và khôi phục
- **Sao lưu**: Tổng quan → "Sao lưu" → đặt mật khẩu sao lưu → "Chọn nơi lưu và xuất file". File `.json` bên trong là dữ liệu mã hóa AES-256-GCM (khóa dẫn xuất PBKDF2-SHA256 150.000 vòng), không có mật khẩu dạng văn bản thuần.
- **Khôi phục**: "Nhập dữ liệu" → chọn file → nhập mật khẩu sao lưu → chọn *Hợp nhất* (bỏ qua Gmail trùng) hoặc *Thay thế toàn bộ* → "Giải mã và nhập dữ liệu".
- Hãy chép file sao lưu ra nơi an toàn (Zalo cloud, máy tính, Google Drive...). Gỡ app hoặc xóa dữ liệu app là mất sạch dữ liệu nếu chưa sao lưu.

## 6. Bảo mật
- Mật khẩu Gmail trong database được mã hóa AES-256-GCM bằng khóa nằm trong Android Keystore; không ghi log mật khẩu; tắt `allowBackup`; không có quyền Internet; chặn chụp màn hình.
- Mật khẩu kho được băm PBKDF2 và dùng để khóa giao diện (tự khóa khi thoát app hoặc sau thời gian không hoạt động). Khóa mã hóa dữ liệu nằm trong Keystore của thiết bị, nên máy đã root có thể là điểm yếu.

## 7. Kiểm thử 1.000 tài khoản
File `app/src/androidTest/.../StressTest.kt` thêm 1.000 tài khoản vào database tạm, rồi đọc lại và kiểm tra giải mã. Chạy bằng `./gradlew connectedDebugAndroidTest` khi có máy thật hoặc giả lập nối với Android Studio. Dữ liệu thử chỉ nằm trong database tạm, không lẫn vào dữ liệu thật của app.
