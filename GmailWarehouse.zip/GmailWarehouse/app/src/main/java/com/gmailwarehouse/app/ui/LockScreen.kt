package com.gmailwarehouse.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gmailwarehouse.app.AppViewModel

@Composable
fun LockScreen(vm: AppViewModel) {
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp).imePadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(88.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Lock, null, tint = Color.White, modifier = Modifier.size(44.dp))
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("Gmail Warehouse", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (!vm.hasVault) {
            Text(
                "Tạo mật khẩu kho để bảo vệ dữ liệu. Nếu quên mật khẩu này sẽ không thể mở kho, hãy nhớ kỹ và sao lưu thường xuyên.",
                textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(16.dp))
            PasswordField(pw, { pw = it }, "Mật khẩu kho (tối thiểu 6 ký tự)")
            Spacer(Modifier.height(8.dp))
            PasswordField(pw2, { pw2 = it }, "Nhập lại mật khẩu kho", imeAction = ImeAction.Done, onDone = { vm.createVault(pw, pw2) })
            Spacer(Modifier.height(16.dp))
            Button(onClick = { vm.createVault(pw, pw2) }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Tạo kho", fontSize = 16.sp)
            }
        } else {
            Text("Nhập mật khẩu để mở kho", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            PasswordField(pw, { pw = it }, "Mật khẩu kho", imeAction = ImeAction.Done, onDone = { vm.unlock(pw) })
            Spacer(Modifier.height(16.dp))
            Button(onClick = { vm.unlock(pw) }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Mở khóa", fontSize = 16.sp)
            }
        }
    }
}
