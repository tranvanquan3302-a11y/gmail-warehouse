package com.gmailwarehouse.app

import android.os.Bundle
import android.view.MotionEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.gmailwarehouse.app.ui.BackupScreen
import com.gmailwarehouse.app.ui.DetailScreen
import com.gmailwarehouse.app.ui.EditScreen
import com.gmailwarehouse.app.ui.GWTheme
import com.gmailwarehouse.app.ui.HomeScaffold
import com.gmailwarehouse.app.ui.LockScreen
import com.gmailwarehouse.app.ui.SettingsScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Chặn chụp màn hình / xem trước trong "ứng dụng gần đây" vì có hiển thị mật khẩu
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            GWTheme(vm.darkMode) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppRoot(vm)
                }
            }
        }
        lifecycleScope.launch {
            while (true) { delay(5_000); vm.checkIdle() }
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        vm.touch()
        return super.dispatchTouchEvent(ev)
    }

    override fun onStart() { super.onStart(); vm.onForegrounded() }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) vm.onBackgrounded()
    }
}

@Composable
fun AppRoot(vm: AppViewModel) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
    BackHandler(enabled = !vm.locked && vm.stack.isNotEmpty()) { vm.pop() }

    Box(Modifier.fillMaxSize()) {
        if (vm.locked) {
            LockScreen(vm)
        } else {
            when (val top = vm.stack.lastOrNull()) {
                null -> HomeScaffold(vm)
                is Screen.Detail -> DetailScreen(vm, top.id)
                is Screen.Edit -> EditScreen(vm, top.id)
                Screen.Backup -> BackupScreen(vm)
                Screen.Settings -> SettingsScreen(vm)
            }
        }
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
        SnackbarHost(
            snack,
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = if (vm.locked) 16.dp else 88.dp)
        )
    }
}
