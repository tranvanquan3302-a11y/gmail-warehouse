package com.gmailwarehouse.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gmailwarehouse.app.AppViewModel

@Composable
private fun SettingCard(title: String, content: @Composable () -> Unit) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            content()
        }
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label)
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val accounts by vm.accounts.collectAsState()
    val vms by vm.vms.collectAsState()
    var oldPw by remember { mutableStateOf("") }
    var newPw by remember { mutableStateOf("") }
    var newPw2 by remember { mutableStateOf("") }

    SubScaffold(title = "Cài đặt", onBack = { vm.pop() }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SettingCard("Giao diện") {
                RadioRow("Theo hệ thống", vm.darkMode == 0) { vm.setDarkMode(0) }
                RadioRow("Chế độ sáng", vm.darkMode == 1) { vm.setDarkMode(1) }
                RadioRow("Chế độ tối", vm.darkMode == 2) { vm.setDarkMode(2) }
            }
            SettingCard("Tự khóa kho") {
                RadioRow("Chỉ khi thoát ứng dụng", vm.autoLockSec == 0) { vm.setAutoLock(0) }
                RadioRow("Sau 1 phút không hoạt động", vm.autoLockSec == 60) { vm.setAutoLock(60) }
                RadioRow("Sau 5 phút không hoạt động", vm.autoLockSec == 300) { vm.setAutoLock(300) }
                RadioRow("Sau 15 phút không hoạt động", vm.autoLockSec == 900) { vm.setAutoLock(900) }
                Text("Kho luôn bị khóa khi mở lại ứng dụng từ đầu.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClick = { vm.lock() }, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("Khóa kho ngay") }
            }
            SettingCard("Clipboard") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Tự xóa mật khẩu đã sao chép")
                        Text("Xóa clipboard sau 60 giây", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = vm.clearClipboard, onCheckedChange = { vm.setClearClipboardPref(it) })
                }
            }
            SettingCard("Đổi mật khẩu kho") {
                PasswordField(oldPw, { oldPw = it }, "Mật khẩu hiện tại")
                PasswordField(newPw, { newPw = it }, "Mật khẩu mới (tối thiểu 6 ký tự)")
                PasswordField(newPw2, { newPw2 = it }, "Nhập lại mật khẩu mới")
                Button(
                    onClick = { vm.changeVaultPassword(oldPw, newPw, newPw2) { oldPw = ""; newPw = ""; newPw2 = "" } },
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) { Text("Đổi mật khẩu") }
            }
            SettingCard("Sao lưu") {
                OutlinedButton(onClick = { vm.push(com.gmailwarehouse.app.Screen.Backup) }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    Text("Mở sao lưu và khôi phục")
                }
            }
            SettingCard("Thông tin") {
                Text("Đang lưu: ${accounts.size} Gmail, ${vms.size} máy ảo")
                Text("Ứng dụng hoạt động hoàn toàn offline, không có quyền Internet. Mật khẩu Gmail được mã hóa AES-256-GCM bằng khóa trong Android Keystore. " +
                    "Màn hình bị chặn chụp ảnh để tránh lộ mật khẩu.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Phiên bản 1.0", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
