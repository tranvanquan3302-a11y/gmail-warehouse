package com.gmailwarehouse.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object Crypto {
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "gmail_warehouse_master_key"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    const val BACKUP_ITERATIONS = 150_000
    private val random = SecureRandom()

    fun randomBytes(n: Int): ByteArray = ByteArray(n).also { random.nextBytes(it) }
    fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    fun unb64(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)

    fun pbkdf2(password: CharArray, salt: ByteArray, iterations: Int, bits: Int): ByteArray {
        val spec = PBEKeySpec(password, salt, iterations, bits)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    @Synchronized
    private fun masterKey(): SecretKey {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = ks.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        gen.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    /** Mã hóa mật khẩu lưu trong database bằng khóa AES-256 nằm trong Android Keystore. */
    fun encrypt(plain: String): String {
        val c = Cipher.getInstance(TRANSFORMATION)
        c.init(Cipher.ENCRYPT_MODE, masterKey())
        val iv = c.iv
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return b64(iv + ct)
    }

    fun decrypt(token: String): String {
        val raw = unb64(token)
        val iv = raw.copyOfRange(0, 12)
        val ct = raw.copyOfRange(12, raw.size)
        val c = Cipher.getInstance(TRANSFORMATION)
        c.init(Cipher.DECRYPT_MODE, masterKey(), GCMParameterSpec(128, iv))
        return String(c.doFinal(ct), Charsets.UTF_8)
    }

    /** Mã hóa toàn bộ bản sao lưu bằng khóa dẫn xuất từ mật khẩu sao lưu (PBKDF2 + AES-256-GCM). */
    fun encryptBackup(plain: String, password: String): String {
        val salt = randomBytes(16)
        val iv = randomBytes(12)
        val key = SecretKeySpec(pbkdf2(password.toCharArray(), salt, BACKUP_ITERATIONS, 256), "AES")
        val c = Cipher.getInstance(TRANSFORMATION)
        c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return JSONObject()
            .put("format", "GmailWarehouseBackup")
            .put("version", 1)
            .put("kdf", "PBKDF2-HMAC-SHA256")
            .put("iterations", BACKUP_ITERATIONS)
            .put("salt", b64(salt))
            .put("iv", b64(iv))
            .put("data", b64(ct))
            .toString()
    }

    fun decryptBackup(text: String, password: String): String {
        val o = JSONObject(text)
        require(o.getString("format") == "GmailWarehouseBackup")
        val salt = unb64(o.getString("salt"))
        val iv = unb64(o.getString("iv"))
        val data = unb64(o.getString("data"))
        val key = SecretKeySpec(pbkdf2(password.toCharArray(), salt, o.getInt("iterations"), 256), "AES")
        val c = Cipher.getInstance(TRANSFORMATION)
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return String(c.doFinal(data), Charsets.UTF_8)
    }
}

object VaultPrefs {
    private const val VAULT_ITER = 120_000
    private fun p(c: Context) = c.getSharedPreferences("gw_prefs", Context.MODE_PRIVATE)

    fun hasVault(c: Context) = p(c).contains("vault_hash")

    fun setPassword(c: Context, pw: String) {
        val salt = Crypto.randomBytes(16)
        val hash = Crypto.pbkdf2(pw.toCharArray(), salt, VAULT_ITER, 256)
        p(c).edit()
            .putString("vault_salt", Crypto.b64(salt))
            .putString("vault_hash", Crypto.b64(hash))
            .putInt("vault_iter", VAULT_ITER)
            .commit()
    }

    fun verify(c: Context, pw: String): Boolean {
        val s = p(c)
        val salt = s.getString("vault_salt", null) ?: return false
        val stored = s.getString("vault_hash", null) ?: return false
        val hash = Crypto.pbkdf2(pw.toCharArray(), Crypto.unb64(salt), s.getInt("vault_iter", VAULT_ITER), 256)
        return MessageDigest.isEqual(hash, Crypto.unb64(stored))
    }

    fun darkMode(c: Context) = p(c).getInt("dark_mode", 0)          // 0 hệ thống, 1 sáng, 2 tối
    fun setDarkMode(c: Context, v: Int) { p(c).edit().putInt("dark_mode", v).apply() }
    fun autoLockSec(c: Context) = p(c).getInt("auto_lock_sec", 60)  // 0 = chỉ khóa khi thoát app
    fun setAutoLockSec(c: Context, v: Int) { p(c).edit().putInt("auto_lock_sec", v).apply() }
    fun clearClipboard(c: Context) = p(c).getBoolean("clear_clip", true)
    fun setClearClipboard(c: Context, v: Boolean) { p(c).edit().putBoolean("clear_clip", v).apply() }
}
