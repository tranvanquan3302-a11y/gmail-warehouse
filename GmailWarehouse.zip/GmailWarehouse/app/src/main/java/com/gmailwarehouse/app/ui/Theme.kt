package com.gmailwarehouse.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF1565C0), onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4FF), onPrimaryContainer = Color(0xFF001B3E),
    secondary = Color(0xFF1E88E5), background = Color(0xFFF3F7FE),
    surface = Color.White, surfaceVariant = Color(0xFFE3ECFA), error = Color(0xFFD32F2F)
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFF90CAF9), onPrimary = Color(0xFF00315C),
    primaryContainer = Color(0xFF0D47A1), onPrimaryContainer = Color(0xFFD6E4FF),
    secondary = Color(0xFF64B5F6), background = Color(0xFF0E141B),
    surface = Color(0xFF151C25), surfaceVariant = Color(0xFF212B38)
)

@Composable
fun GWTheme(darkMode: Int, content: @Composable () -> Unit) {
    val dark = when (darkMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
