@file:OptIn(ExperimentalMaterial3Api::class)

package com.gmailwarehouse.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gmailwarehouse.app.AccountForm
import com.gmailwarehouse.app.AccountView
import com.gmailwarehouse.app.AppViewModel
import com.gmailwarehouse.app.Screen
import com.gmailwarehouse.app.data.Status

@Composable
fun AccountListScreen(vm: AppViewModel, fixedStatus: String?, overview: Boolean) {
    val views by vm.views.collectAsState()
    val now by rememberNow()
    val q = vm.query.trim().lowercase()
    val statusSel = fixedStatus ?: vm.statusFilter
    val gameSel = vm.gameFilter
    val games = remember(views) { views.map { it.acc.game }.distinct().sorted() }
    val filtered = remember(views, q, statusSel, gameSel) {
        views.filter { v ->
            (statusSel == null || v.acc.status == statusSel) &&
                (gameSel == null || v.acc.game == gameSel) &&
                (q.isEmpty() || v.acc.email.lowercase().contains(q) || v.vms.any { it.name.lowercase().contains(q) })
        }.sortedWith(accountComparator)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (overview) {
            item { StatsRow(views, vm) }
            item {
                Button(
                    onClick = { vm.push(Screen.Edit(null)) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Thêm tài khoản", fontSize = 16.sp)
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { vm.push(Screen.Backup) }, modifier = Modifier.weight(1f).height(48.dp)) {
                        Icon(Icons.Default.Backup, null); Spacer(Modifier.width(6.dp)); Text("Sao lưu")
                    }
                    OutlinedButton(onClick = { vm.push(Screen.Backup) }, modifier = Modifier.weight(1f).height(48.dp)) {
                        Icon(Icons.Default.Restore, null); Spacer(Modifier.width(6.dp)); Text("Nhập dữ liệu")
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = vm.query, onValueChange = { vm.query = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Text("Tìm theo Gmail hoặc tên máy ảo") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = {
                    if (vm.query.isNotEmpty()) IconButton(onClick = { vm.query = "" }) { Icon(Icons.Default.Close, "Xóa") }
                },
                shape = RoundedCornerShape(16.dp)
            )
        }
        if (overview) {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = vm.statusFilter == null, onClick = { vm.statusFilter = null }, label = { Text("Tất cả") })
                    Status.all.forEach { s ->
                        FilterChip(selected = vm.statusFilter == s, onClick = { vm.statusFilter = s }, label = { Text(Status.label(s)) })
                    }
                }
            }
        }
        if (games.isNotEmpty()) {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = gameSel == null, onClick = { vm.gameFilter = null }, label = { Text("Mọi game") })
                    games.forEach { g ->
                        FilterChip(selected = gameSel == g, onClick = { vm.gameFilter = g }, label = { Text(g) })
                    }
                }
            }
        }
        if (filtered.isEmpty()) {
            item {
                Text(
                    if (views.isEmpty()) "Kho đang trống. Bấm \"Thêm tài khoản\" để bắt đầu." else "Không có tài khoản phù hợp.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 24.dp)
                )
            }
        }
        items(filtered, key = { it.acc.id }) { v -> AccountCard(v, now, vm) }
        item { Spacer(Modifier.height(80.dp)) }
    }
}

@Composable
fun StatsRow(views: List<AccountView>, vm: AppViewModel) {
    val stats = listOf(
        Triple("Gmail chưa dùng", Status.UNUSED, 1),
        Triple("Gmail đang dùng", Status.IN_USE, 2),
        Triple("Gmail bị ban", Status.BANNED, 3)
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        stats.forEach { (label, status, tabIndex) ->
            Card(
                onClick = { vm.tab = tabIndex },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = statusColor(status).copy(alpha = 0.12f))
            ) {
                Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(views.count { it.acc.status == status }.toString(), fontSize = 28.sp,
                        fontWeight = FontWeight.Bold, color = statusColor(status))
                    Text(label, fontSize = 12.sp, maxLines = 2)
                }
            }
        }
    }
}

@Composable
fun AccountCard(v: AccountView, now: Long, vm: AppViewModel) {
    val a = v.acc
    Card(
        onClick = { vm.push(Screen.Detail(a.id)) },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(v.vms.firstOrNull()?.name ?: "Chưa gắn máy ảo", fontWeight = FontWeight.Bold,
                    fontSize = 20.sp, modifier = Modifier.weight(1f))
                StatusBadge(a.status)
            }
            InfoLine("Gmail", a.email)
            InfoLine("Game", a.game)
            InfoLine("Trạng thái", Status.label(a.status))
            if (v.vms.isNotEmpty()) {
                InfoLine("Máy ảo", v.vms.joinToString { it.name })
                InfoLine("Thời hạn", formatRemaining(v.vms.first().expiresAt, now))
            }
            val banned = a.bannedAt
            if (a.status == Status.BANNED && banned != null) InfoLine("Ngày ban", formatDate(banned))
            if (a.note.isNotBlank()) InfoLine("Ghi chú", a.note)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = { vm.copyText("Gmail", a.email, false) },
                    modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)
                ) { Text("Sao chép Gmail", fontSize = 12.sp, maxLines = 1) }
                Button(
                    onClick = { vm.copyText("mật khẩu", vm.decryptPassword(a), true) },
                    modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)
                ) { Text("Sao chép mật khẩu", fontSize = 12.sp, maxLines = 1) }
                OutlinedButton(
                    onClick = { vm.push(Screen.Edit(a.id)) },
                    modifier = Modifier.weight(0.7f), contentPadding = PaddingValues(horizontal = 4.dp)
                ) { Text("Sửa", fontSize = 12.sp, maxLines = 1) }
            }
        }
    }
}

@Composable
fun DetailScreen(vm: AppViewModel, id: Long) {
    val views by vm.views.collectAsState()
    val now by rememberNow()
    val v = views.firstOrNull { it.acc.id == id }
    if (v == null) {
        LaunchedEffect(Unit) { vm.pop() }
        return
    }
    val a = v.acc
    var show by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val password = remember(a.passwordEnc) { vm.decryptPassword(a) }

    SubScaffold(
        title = v.vms.firstOrNull()?.name ?: "Chi tiết tài khoản",
        onBack = { vm.pop() },
        actions = {
            IconButton(onClick = { vm.push(Screen.Edit(a.id)) }) { Icon(Icons.Default.Edit, "Sửa") }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, "Xóa") }
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Thông tin", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                        StatusBadge(a.status)
                    }
                    InfoLine("Gmail", a.email)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Mật khẩu: ", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                        Text(if (show) password else "••••••••••", fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                        IconButton(onClick = { show = !show }) {
                            Icon(if (show) Icons.Default.VisibilityOff else Icons.Default.Visibility, if (show) "Ẩn" else "Hiện")
                        }
                    }
                    InfoLine("Game", a.game)
                    InfoLine("Ngày thêm", formatDate(a.addedAt))
                    val banned = a.bannedAt
                    if (banned != null) InfoLine("Ngày bị ban", formatDate(banned))
                    if (a.note.isNotBlank()) InfoLine("Ghi chú", a.note)
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.copyText("Gmail", a.email, false) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(6.dp)); Text("Gmail", maxLines = 1)
                        }
                        Button(onClick = { vm.copyText("mật khẩu", password, true) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(6.dp)); Text("Mật khẩu", maxLines = 1)
                        }
                    }
                }
            }
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Chuyển trạng thái", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Status.all.forEach { s ->
                            FilterChip(selected = a.status == s, onClick = { if (a.status != s) vm.setStatus(a.id, s) },
                                label = { Text(Status.label(s)) })
                        }
                    }
                    Text("Chuyển sang \"Chưa dùng\" hoặc \"Bị ban\" sẽ tự gỡ Gmail khỏi máy ảo.",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Máy ảo liên kết", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    if (v.vms.isEmpty()) Text("Chưa liên kết máy ảo nào.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    v.vms.forEachIndexed { i, vmE ->
                        if (i > 0) HorizontalDivider()
                        InfoLine("Máy ảo", vmE.name)
                        InfoLine("Game", vmE.game.ifBlank { "—" })
                        InfoLine("Hoạt động", if (vmE.active) "Đang chạy" else "Tạm dừng")
                        InfoLine("Thời hạn", formatRemaining(vmE.expiresAt, now))
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Xóa tài khoản?") },
            text = { Text("Xóa ${a.email} khỏi kho. Không thể hoàn tác (trừ khi bạn có bản sao lưu).") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.deleteAccount(a.id) { vm.pop() } }) { Text("Xóa") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Hủy") } }
        )
    }
}

@Composable
fun EditScreen(vm: AppViewModel, id: Long?) {
    val accounts by vm.accounts.collectAsState()
    val allVms by vm.vms.collectAsState()
    val view = remember(id) { if (id == null) null else vm.views.value.firstOrNull { it.acc.id == id } }
    val firstVm = view?.vms?.firstOrNull()
    val initialVm = firstVm?.name ?: ""
    val rem = remember(id) { splitRemaining(firstVm?.expiresAt) }

    var email by remember { mutableStateOf(view?.acc?.email ?: "") }
    var password by remember { mutableStateOf(view?.let { vm.decryptPassword(it.acc) } ?: "") }
    var game by remember { mutableStateOf(view?.acc?.game ?: "Rio Rise") }
    var status by remember { mutableStateOf(view?.acc?.status ?: Status.UNUSED) }
    var note by remember { mutableStateOf(view?.acc?.note ?: "") }
    var vmName by remember { mutableStateOf(initialVm) }
    var days by remember { mutableStateOf(rem.first) }
    var hours by remember { mutableStateOf(rem.second) }

    val knownGames = remember(accounts) { (listOf("Rio Rise") + accounts.map { it.game }).distinct() }
    val freeVms = remember(allVms) {
        allVms.filter { it.accountId == null || it.accountId == id }.sortedWith { x, y -> naturalCompare(x.name, y.name) }
    }

    SubScaffold(title = if (id == null) "Thêm Gmail" else "Sửa Gmail", onBack = { vm.pop() }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = email, onValueChange = { email = it }, label = { Text("Địa chỉ Gmail") },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
            )
            PasswordField(password, { password = it }, "Mật khẩu Gmail")
            OutlinedTextField(value = game, onValueChange = { game = it }, label = { Text("Tên game") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                knownGames.forEach { g -> FilterChip(selected = game == g, onClick = { game = g }, label = { Text(g) }) }
            }
            Text("Trạng thái", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Status.all.forEach { s -> FilterChip(selected = status == s, onClick = { status = s }, label = { Text(Status.label(s)) }) }
            }
            if (status == Status.IN_USE) {
                OutlinedTextField(value = vmName, onValueChange = { vmName = it }, label = { Text("Tên máy ảo (VD: VIP-1)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
                if (freeVms.isNotEmpty()) {
                    Text("Máy ảo trống:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        freeVms.forEach { m -> FilterChip(selected = vmName.equals(m.name, true), onClick = { vmName = m.name }, label = { Text(m.name) }) }
                    }
                }
                Text("Thời hạn máy ảo", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = days, onValueChange = { days = it.filter(Char::isDigit) }, label = { Text("Ngày") },
                        singleLine = true, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = hours, onValueChange = { hours = it.filter(Char::isDigit) }, label = { Text("Giờ") },
                        singleLine = true, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                Text("Nhập số ngày/giờ còn lại của máy ảo. Để trống nếu không đặt thời hạn. Tên máy ảo mới sẽ được tạo tự động.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text("Chọn trạng thái \"Đang dùng\" để gắn Gmail vào máy ảo.", fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedTextField(
                value = note, onValueChange = { note = it },
                label = { Text(if (status == Status.BANNED) "Ghi chú (nguyên nhân bị ban)" else "Ghi chú") },
                modifier = Modifier.fillMaxWidth(), minLines = 2
            )
            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    vm.saveAccount(id, AccountForm(email, password, game, status, note, vmName, initialVm, days, hours)) { vm.pop() }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)
            ) { Text("Lưu", fontSize = 16.sp) }
        }
    }
}
