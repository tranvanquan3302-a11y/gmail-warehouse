package com.gmailwarehouse.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

object Status {
    const val UNUSED = "UNUSED"
    const val IN_USE = "IN_USE"
    const val BANNED = "BANNED"
    val all = listOf(UNUSED, IN_USE, BANNED)
    fun label(s: String): String = when (s) {
        UNUSED -> "Chưa dùng"
        IN_USE -> "Đang dùng"
        BANNED -> "Bị ban"
        else -> s
    }
}

@Entity(tableName = "accounts", indices = [Index(value = ["email"], unique = true)])
data class AccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val email: String,
    val passwordEnc: String,          // AES-256-GCM (khóa nằm trong Android Keystore), Base64(iv + ciphertext)
    val game: String,
    val status: String,
    val addedAt: Long,
    val bannedAt: Long? = null,
    val note: String = ""
)

@Entity(tableName = "vms", indices = [Index(value = ["name"], unique = true), Index(value = ["accountId"])])
data class VmEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val accountId: Long? = null,
    val game: String = "",
    val active: Boolean = true,
    val expiresAt: Long? = null,
    val note: String = ""
)
