package com.gmailwarehouse.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts") fun observeAll(): Flow<List<AccountEntity>>
    @Query("SELECT * FROM accounts") suspend fun getAll(): List<AccountEntity>
    @Query("SELECT * FROM accounts WHERE id = :id") suspend fun getById(id: Long): AccountEntity?
    @Query("SELECT * FROM accounts WHERE email = :email COLLATE NOCASE LIMIT 1") suspend fun findByEmail(email: String): AccountEntity?
    @Query("SELECT COUNT(*) FROM accounts") suspend fun count(): Int
    @Insert suspend fun insert(a: AccountEntity): Long
    @Update suspend fun update(a: AccountEntity)
    @Query("DELETE FROM accounts WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("DELETE FROM accounts") suspend fun deleteAll()
}

@Dao
interface VmDao {
    @Query("SELECT * FROM vms") fun observeAll(): Flow<List<VmEntity>>
    @Query("SELECT * FROM vms") suspend fun getAll(): List<VmEntity>
    @Query("SELECT * FROM vms WHERE id = :id") suspend fun getById(id: Long): VmEntity?
    @Query("SELECT * FROM vms WHERE name = :name COLLATE NOCASE LIMIT 1") suspend fun findByName(name: String): VmEntity?
    @Query("SELECT COUNT(*) FROM vms WHERE accountId = :accountId") suspend fun countLinked(accountId: Long): Int
    @Insert suspend fun insert(v: VmEntity): Long
    @Update suspend fun update(v: VmEntity)
    @Query("DELETE FROM vms WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("DELETE FROM vms") suspend fun deleteAll()
    @Query("UPDATE vms SET accountId = NULL WHERE accountId = :accountId") suspend fun unlinkAccount(accountId: Long)
}

@Database(entities = [AccountEntity::class, VmEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun accounts(): AccountDao
    abstract fun vms(): VmDao

    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "gmail_warehouse.db")
                .build().also { instance = it }
        }
    }
}
