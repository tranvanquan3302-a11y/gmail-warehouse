package com.gmailwarehouse.app

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.gmailwarehouse.app.data.AccountEntity
import com.gmailwarehouse.app.data.AppDatabase
import com.gmailwarehouse.app.data.Status
import com.gmailwarehouse.app.data.VmEntity
import com.gmailwarehouse.app.security.Crypto
import com.gmailwarehouse.app.security.VaultPrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

sealed interface Screen {
    data class Detail(val id: Long) : Screen
    data class Edit(val id: Long?) : Screen
    data object Backup : Screen
    data object Settings : Screen
}

class UserError(message: String) : Exception(message)

data class AccountView(val acc: AccountEntity, val vms: List<VmEntity>)

data class AccountForm(
    val email: String,
    val password: String,
    val game: String,
    val status: String,
    val note: String,
    val vmName: String,
    val initialVmName: String,
    val days: String,
    val hours: String
)

private const val DAY = 86_400_000L
private const val HOUR = 3_600_000L

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Application get() = getApplication()
    private val db = AppDatabase.get(app)
    private val accDao = db.accounts()
    private val vmDao = db.vms()

    val accounts: StateFlow<List<AccountEntity>> =
        accDao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val vms: StateFlow<List<VmEntity>> =
        vmDao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val views: StateFlow<List<AccountView>> = combine(accounts, vms) { a, v ->
        val byAcc = v.groupBy { it.accountId }
        a.map { acc -> AccountView(acc, byAcc[acc.id].orEmpty().sortedBy { it.name.lowercase() }) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages: SharedFlow<String> = _messages.asSharedFlow()
    fun toast(m: String) { _messages.tryEmit(m) }

    // ---- trạng thái UI ----
    var locked by mutableStateOf(true); private set
    var hasVault by mutableStateOf(VaultPrefs.hasVault(app)); private set
    var busy by mutableStateOf(false); private set
    var tab by mutableIntStateOf(0)
    val stack = mutableStateListOf<Screen>()
    var query by mutableStateOf("")
    var statusFilter by mutableStateOf<String?>(null)
    var gameFilter by mutableStateOf<String?>(null)
    var darkMode by mutableIntStateOf(VaultPrefs.darkMode(app)); private set
    var autoLockSec by mutableIntStateOf(VaultPrefs.autoLockSec(app)); private set
    var clearClipboard by mutableStateOf(VaultPrefs.clearClipboard(app)); private set

    fun push(s: Screen) { stack.add(s) }
    fun pop() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }

    // ---- khóa kho ----
    var pickerActive = false
    private var lastTouch = SystemClock.elapsedRealtime()
    fun touch() { lastTouch = SystemClock.elapsedRealtime() }

    fun lock() { locked = true; stack.clear(); query = "" }
    fun onBackgrounded() { if (!locked && !pickerActive && autoLockSec == 0) lock() }
    fun onForegrounded() {
        if (!locked && !pickerActive && autoLockSec > 0 &&
            SystemClock.elapsedRealtime() - lastTouch > autoLockSec * 1000L) lock()
    }
    fun checkIdle() {
        if (!locked && !pickerActive && autoLockSec > 0 &&
            SystemClock.elapsedRealtime() - lastTouch > autoLockSec * 1000L) lock()
    }

    fun createVault(pw: String, confirm: String) {
        if (pw.length < 6) { toast("Mật khẩu kho tối thiểu 6 ký tự"); return }
        if (pw != confirm) { toast("Mật khẩu nhập lại không khớp"); return }
        viewModelScope.launch {
            busy = true
            withContext(Dispatchers.Default) { VaultPrefs.setPassword(ctx, pw) }
            hasVault = true; busy = false; touch(); locked = false
        }
    }

    fun unlock(pw: String) {
        if (pw.isEmpty()) return
        viewModelScope.launch {
            busy = true
            val ok = withContext(Dispatchers.Default) { VaultPrefs.verify(ctx, pw) }
            busy = false
            if (ok) { touch(); locked = false } else toast("Sai mật khẩu kho")
        }
    }

    fun changeVaultPassword(old: String, new: String, confirm: String, onDone: () -> Unit) {
        if (new.length < 6) { toast("Mật khẩu mới tối thiểu 6 ký tự"); return }
        if (new != confirm) { toast("Mật khẩu nhập lại không khớp"); return }
        viewModelScope.launch {
            busy = true
            val ok = withContext(Dispatchers.Default) {
                if (VaultPrefs.verify(ctx, old)) { VaultPrefs.setPassword(ctx, new); true } else false
            }
            busy = false
            if (ok) { toast("Đã đổi mật khẩu kho"); onDone() } else toast("Mật khẩu hiện tại không đúng")
        }
    }

    fun setDarkMode(v: Int) { darkMode = v; VaultPrefs.setDarkMode(ctx, v) }
    fun setAutoLock(sec: Int) { autoLockSec = sec; VaultPrefs.setAutoLockSec(ctx, sec) }
    fun setClearClipboardPref(v: Boolean) { clearClipboard = v; VaultPrefs.setClearClipboard(ctx, v) }

    // ---- clipboard ----
    private val handler = Handler(Looper.getMainLooper())
    private val clearRunnable = Runnable {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip()
            else cm.setPrimaryClip(ClipData.newPlainText("", ""))
        } catch (e: Exception) { }
    }

    fun copyText(label: String, text: String, sensitive: Boolean) {
        if (text.isEmpty()) { toast("Không có dữ liệu để sao chép"); return }
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        if (sensitive && Build.VERSION.SDK_INT >= 33) {
            clip.description.extras = PersistableBundle().apply {
                putBoolean("android.content.extra.IS_SENSITIVE", true)
            }
        }
        cm.setPrimaryClip(clip)
        toast("Đã sao chép $label")
        if (sensitive && clearClipboard) {
            handler.removeCallbacks(clearRunnable)
            handler.postDelayed(clearRunnable, 60_000)
        }
    }

    fun decryptPassword(a: AccountEntity): String =
        try { Crypto.decrypt(a.passwordEnc) } catch (e: Exception) { "" }

    // ---- tài khoản ----
    fun saveAccount(editId: Long?, f: AccountForm, onDone: () -> Unit) {
        val email = f.email.trim()
        if (email.isEmpty()) { toast("Nhập địa chỉ Gmail"); return }
        if (f.password.isEmpty()) { toast("Nhập mật khẩu Gmail"); return }
        val game = f.game.trim().ifEmpty { "Rio Rise" }
        val vmName = f.vmName.trim()
        val hasExpiry = f.days.isNotBlank() || f.hours.isNotBlank()
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    db.withTransaction {
                        val now = System.currentTimeMillis()
                        val expiry = now + (f.days.trim().toLongOrNull() ?: 0L) * DAY + (f.hours.trim().toLongOrNull() ?: 0L) * HOUR
                        val dup = accDao.findByEmail(email)
                        if (dup != null && dup.id != editId) throw UserError("Gmail này đã có trong kho")
                        val old = editId?.let { accDao.getById(it) }
                        val bannedAt = if (f.status == Status.BANNED) (old?.bannedAt ?: now) else null
                        val entity = AccountEntity(
                            id = editId ?: 0L, email = email, passwordEnc = Crypto.encrypt(f.password),
                            game = game, status = f.status, addedAt = old?.addedAt ?: now,
                            bannedAt = bannedAt, note = f.note.trim()
                        )
                        val id = if (editId == null) accDao.insert(entity) else { accDao.update(entity); editId }
                        when {
                            f.status != Status.IN_USE -> vmDao.unlinkAccount(id)
                            vmName.isEmpty() -> { if (f.initialVmName.isNotEmpty()) vmDao.unlinkAccount(id) }
                            vmName.equals(f.initialVmName, ignoreCase = true) -> {
                                val vm = vmDao.findByName(vmName)
                                if (vm != null) vmDao.update(vm.copy(game = game, expiresAt = if (hasExpiry) expiry else vm.expiresAt))
                            }
                            else -> {
                                val vm = vmDao.findByName(vmName)
                                if (vm != null && vm.accountId != null && vm.accountId != id)
                                    throw UserError("Máy ảo $vmName đang liên kết Gmail khác. Hãy gỡ liên kết ở mục Máy ảo trước.")
                                vmDao.unlinkAccount(id)
                                if (vm == null) vmDao.insert(VmEntity(name = vmName, accountId = id, game = game, expiresAt = if (hasExpiry) expiry else null))
                                else vmDao.update(vm.copy(accountId = id, game = game, expiresAt = if (hasExpiry) expiry else vm.expiresAt))
                            }
                        }
                        Unit
                    }
                }
                toast("Đã lưu tài khoản"); onDone()
            } catch (e: UserError) { toast(e.message ?: "Lỗi")
            } catch (e: Exception) { toast("Lỗi lưu dữ liệu") }
        }
    }

    fun setStatus(id: Long, status: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                db.withTransaction {
                    val a = accDao.getById(id)
                    if (a != null) {
                        val now = System.currentTimeMillis()
                        accDao.update(a.copy(status = status, bannedAt = if (status == Status.BANNED) (a.bannedAt ?: now) else null))
                        if (status != Status.IN_USE) vmDao.unlinkAccount(id)
                    }
                    Unit
                }
            }
            toast("Đã chuyển sang: ${Status.label(status)}")
        }
    }

    fun deleteAccount(id: Long, onDone: () -> Unit) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                db.withTransaction { vmDao.unlinkAccount(id); accDao.deleteById(id); Unit }
            }
            toast("Đã xóa tài khoản"); onDone()
        }
    }

    // ---- máy ảo ----
    fun saveVm(editId: Long?, name: String, game: String, active: Boolean, days: String, hours: String, note: String, onDone: () -> Unit) {
        val n = name.trim()
        if (n.isEmpty()) { toast("Nhập tên máy ảo"); return }
        val hasExpiry = days.isNotBlank() || hours.isNotBlank()
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    db.withTransaction {
                        val dup = vmDao.findByName(n)
                        if (dup != null && dup.id != editId) throw UserError("Tên máy ảo đã tồn tại")
                        val exp = if (hasExpiry) System.currentTimeMillis() +
                            (days.trim().toLongOrNull() ?: 0L) * DAY + (hours.trim().toLongOrNull() ?: 0L) * HOUR else null
                        val old = editId?.let { vmDao.getById(it) }
                        if (old == null) vmDao.insert(VmEntity(name = n, game = game.trim(), active = active, expiresAt = exp, note = note.trim()))
                        else vmDao.update(old.copy(name = n, game = game.trim(), active = active, expiresAt = exp, note = note.trim()))
                        Unit
                    }
                }
                toast("Đã lưu máy ảo"); onDone()
            } catch (e: UserError) { toast(e.message ?: "Lỗi")
            } catch (e: Exception) { toast("Lỗi lưu máy ảo") }
        }
    }

    fun addVmsBulk(prefix: String, start: String, count: String, game: String, onDone: () -> Unit) {
        val s = start.trim().toIntOrNull(); val c = count.trim().toIntOrNull()
        if (s == null || c == null || c < 1 || c > 1000) { toast("Số bắt đầu / số lượng không hợp lệ (tối đa 1000)"); return }
        viewModelScope.launch {
            val added = withContext(Dispatchers.IO) {
                db.withTransaction {
                    var n = 0
                    for (i in s until s + c) {
                        val name = prefix.trim() + i
                        if (vmDao.findByName(name) == null) { vmDao.insert(VmEntity(name = name, game = game.trim())); n++ }
                    }
                    n
                }
            }
            toast("Đã tạo $added máy ảo"); onDone()
        }
    }

    fun setVmActive(id: Long, active: Boolean) {
        viewModelScope.launch { withContext(Dispatchers.IO) { vmDao.getById(id)?.let { vmDao.update(it.copy(active = active)) } } }
    }

    fun deleteVm(id: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                db.withTransaction {
                    val vm = vmDao.getById(id)
                    vmDao.deleteById(id)
                    vm?.accountId?.let { releaseIfIdle(it) }
                    Unit
                }
            }
            toast("Đã xóa máy ảo")
        }
    }

    private suspend fun releaseIfIdle(accountId: Long) {
        if (vmDao.countLinked(accountId) == 0) {
            val a = accDao.getById(accountId)
            if (a != null && a.status == Status.IN_USE) accDao.update(a.copy(status = Status.UNUSED))
        }
    }

    fun linkVm(vmId: Long, accountId: Long, allowShared: Boolean, onDone: () -> Unit) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    db.withTransaction {
                        val acc = accDao.getById(accountId) ?: throw UserError("Không tìm thấy Gmail")
                        val vm = vmDao.getById(vmId) ?: throw UserError("Không tìm thấy máy ảo")
                        if (acc.status == Status.BANNED) throw UserError("Gmail này đang bị ban, hãy đổi trạng thái trước")
                        val others = vmDao.getAll().filter { it.accountId == acc.id && it.id != vm.id }
                        if (others.isNotEmpty() && !allowShared)
                            throw UserError("Gmail đang gắn với ${others.joinToString { it.name }}. Tick \"cho phép\" nếu muốn dùng chung.")
                        val prev = vm.accountId
                        vmDao.update(vm.copy(accountId = acc.id, game = vm.game.ifBlank { acc.game }))
                        if (acc.status != Status.IN_USE) accDao.update(acc.copy(status = Status.IN_USE, bannedAt = null))
                        if (prev != null && prev != acc.id) releaseIfIdle(prev)
                        Unit
                    }
                }
                toast("Đã liên kết"); onDone()
            } catch (e: UserError) { toast(e.message ?: "Lỗi")
            } catch (e: Exception) { toast("Lỗi liên kết") }
        }
    }

    fun unlinkVm(vmId: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                db.withTransaction {
                    val vm = vmDao.getById(vmId)
                    if (vm != null) {
                        val prev = vm.accountId
                        vmDao.update(vm.copy(accountId = null))
                        if (prev != null) releaseIfIdle(prev)
                    }
                    Unit
                }
            }
            toast("Đã gỡ liên kết")
        }
    }

    // ---- sao lưu / khôi phục ----
    fun exportBackup(uri: Uri, password: String) {
        viewModelScope.launch {
            busy = true
            try {
                withContext(Dispatchers.IO) {
                    val accs = accDao.getAll()
                    val vs = vmDao.getAll()
                    val byId = accs.associateBy { it.id }
                    val root = JSONObject().put("app", "gmail-warehouse").put("version", 1)
                        .put("exportedAt", System.currentTimeMillis())
                    val ja = JSONArray()
                    accs.forEach {
                        ja.put(JSONObject().put("email", it.email).put("password", Crypto.decrypt(it.passwordEnc))
                            .put("game", it.game).put("status", it.status).put("addedAt", it.addedAt)
                            .put("bannedAt", it.bannedAt ?: JSONObject.NULL).put("note", it.note))
                    }
                    val jv = JSONArray()
                    vs.forEach {
                        jv.put(JSONObject().put("name", it.name).put("accountEmail", it.accountId?.let { id -> byId[id]?.email } ?: JSONObject.NULL)
                            .put("game", it.game).put("active", it.active)
                            .put("expiresAt", it.expiresAt ?: JSONObject.NULL).put("note", it.note))
                    }
                    root.put("accounts", ja).put("vms", jv)
                    // Toàn bộ nội dung (kể cả mật khẩu) chỉ nằm trong khối đã mã hóa AES-256-GCM
                    val text = Crypto.encryptBackup(root.toString(), password)
                    val out = ctx.contentResolver.openOutputStream(uri, "wt") ?: throw UserError("Không ghi được file")
                    out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                }
                toast("Đã xuất bản sao lưu mã hóa")
            } catch (e: UserError) { toast(e.message ?: "Lỗi")
            } catch (e: Exception) { toast("Xuất thất bại") }
            busy = false
        }
    }

    fun importBackup(uri: Uri, password: String, replace: Boolean) {
        viewModelScope.launch {
            busy = true
            try {
                val msg = withContext(Dispatchers.IO) {
                    val input = ctx.contentResolver.openInputStream(uri) ?: throw UserError("Không đọc được file")
                    val text = input.use { it.readBytes().toString(Charsets.UTF_8) }
                    val json = try { Crypto.decryptBackup(text, password) }
                    catch (e: Exception) { throw UserError("Sai mật khẩu sao lưu hoặc file bị hỏng") }
                    val root = JSONObject(json)
                    if (root.optString("app") != "gmail-warehouse") throw UserError("Không phải bản sao lưu Gmail Warehouse")
                    val accArr = root.getJSONArray("accounts")
                    val vmArr = root.optJSONArray("vms") ?: JSONArray()
                    var added = 0; var dups = 0; var vmAdded = 0
                    db.withTransaction {
                        if (replace) { vmDao.deleteAll(); accDao.deleteAll() }
                        for (i in 0 until accArr.length()) {
                            val o = accArr.getJSONObject(i)
                            val email = o.getString("email").trim()
                            if (email.isEmpty()) continue
                            if (accDao.findByEmail(email) != null) { dups++; continue }
                            val st = o.optString("status", Status.UNUSED).let { if (it in Status.all) it else Status.UNUSED }
                            accDao.insert(AccountEntity(
                                email = email, passwordEnc = Crypto.encrypt(o.getString("password")),
                                game = o.optString("game", "Rio Rise"), status = st,
                                addedAt = o.optLong("addedAt", System.currentTimeMillis()),
                                bannedAt = if (o.isNull("bannedAt")) null else o.optLong("bannedAt"),
                                note = o.optString("note", "")
                            ))
                            added++
                        }
                        for (i in 0 until vmArr.length()) {
                            val o = vmArr.getJSONObject(i)
                            val name = o.getString("name").trim()
                            if (name.isEmpty() || vmDao.findByName(name) != null) continue
                            val accId = if (o.isNull("accountEmail")) null else accDao.findByEmail(o.getString("accountEmail"))?.id
                            vmDao.insert(VmEntity(
                                name = name, accountId = accId, game = o.optString("game", ""),
                                active = o.optBoolean("active", true),
                                expiresAt = if (o.isNull("expiresAt")) null else o.optLong("expiresAt"),
                                note = o.optString("note", "")
                            ))
                            vmAdded++
                        }
                        Unit
                    }
                    "Đã nhập $added tài khoản, bỏ qua $dups trùng, thêm $vmAdded máy ảo"
                }
                toast(msg)
            } catch (e: UserError) { toast(e.message ?: "Lỗi")
            } catch (e: Exception) { toast("Nhập thất bại") }
            busy = false
        }
    }
}
