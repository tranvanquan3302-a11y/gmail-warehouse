package com.gmailwarehouse.app

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.gmailwarehouse.app.data.AccountEntity
import com.gmailwarehouse.app.data.AppDatabase
import com.gmailwarehouse.app.data.Status
import com.gmailwarehouse.app.security.Crypto
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith

/** Chạy bằng: ./gradlew connectedDebugAndroidTest (cần máy thật/giả lập). Kiểm tra lưu 1.000 tài khoản. */
@RunWith(AndroidJUnit4::class)
class StressTest {
    @Test
    fun insertAndReadBack1000Accounts() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase::class.java).build()
        runBlocking {
            repeat(1000) { i ->
                db.accounts().insert(
                    AccountEntity(email = "stress$i@example.test", passwordEnc = Crypto.encrypt("pw$i"),
                        game = "Rio Rise", status = Status.UNUSED, addedAt = System.currentTimeMillis())
                )
            }
            assertEquals(1000, db.accounts().count())
            assertEquals("pw999", Crypto.decrypt(db.accounts().findByEmail("stress999@example.test")!!.passwordEnc))
        }
        db.close()
    }
}
