package com.gmailwarehouse.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gmailwarehouse.app.AppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BackupScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    var exportPw by remember { mutableStateOf("") }
    var exportPw2 by remember { mutableStateOf("") }
    var importPw by remember { mutableStateOf("") }
    var importUri by remember { mutableStateOf<Uri?>(null) }
    var importName by remember { mutableStateOf("") }
    var replace by remember { mutableStateOf(false) }
    var confirmReplace by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        vm.pickerActive = false; vm.touch()
        if (uri != null) vm.exportBackup(uri, exportPw)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        vm.pickerActive = false; vm.touch()
        if (uri != null) { importUri = uri; importName = fileName(ctx, uri) }
    }

    SubScaffold(title = "Sao lưu và khôi phục", onBack = { vm.pop() }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Xuất sao lưu", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Xuất toàn bộ Gmail, mật khẩu, máy ảo, trạng thái và ghi chú ra một file JSON đã mã hóa AES-256-GCM. " +
                        "Mật khẩu không bao giờ nằm ở dạng văn bản thuần trong file. Nếu quên mật khẩu sao lưu sẽ không khôi phục được.",
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    PasswordField(exportPw, { exportPw = it }, "Mật khẩu sao lưu (tối thiểu 6 ký tự)")
                    PasswordField(exportPw2, { exportPw2 = it }, "Nhập lại mật khẩu sao lưu")
                    Button(
                        onClick = {
                            when {
                                exportPw.length < 6 -> vm.toast("Mật khẩu sao lưu tối thiểu 6 ký tự")
                                exportPw != exportPw2 -> vm.toast("Mật khẩu nhập lại không khớp")
                                else -> {
                                    vm.pickerActive = true
                                    val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
                                    exportLauncher.launch("gmail-warehouse-$stamp.json")
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)
                    ) { Text("Chọn nơi lưu và xuất file", fontSize = 16.sp) }
                }
            }
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Nhập / khôi phục", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    OutlinedButton(
                        onClick = { vm.pickerActive = true; importLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) { Text(if (importUri == null) "Chọn file sao lưu" else "Đã chọn: $importName") }
                    PasswordField(importPw, { importPw = it }, "Mật khẩu sao lưu")
                    Row(Modifier.fillMaxWidth().clickable { replace = false }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = !replace, onClick = { replace = false })
                        Column {
                            Text("Hợp nhất", fontWeight = FontWeight.Medium)
                            Text("Giữ dữ liệu hiện có, chỉ thêm tài khoản mới, bỏ qua Gmail trùng.", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Row(Modifier.fillMaxWidth().clickable { replace = true }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = replace, onClick = { replace = true })
                        Column {
                            Text("Thay thế toàn bộ", fontWeight = FontWeight.Medium)
                            Text("Xóa dữ liệu hiện tại rồi nạp lại từ file sao lưu.", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Button(
                        onClick = {
                            val u = importUri
                            when {
                                u == null -> vm.toast("Hãy chọn file sao lưu")
                                importPw.isEmpty() -> vm.toast("Nhập mật khẩu sao lưu")
                                replace -> confirmReplace = true
                                else -> vm.importBackup(u, importPw, false)
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)
                    ) { Text("Giải mã và nhập dữ liệu", fontSize = 16.sp) }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmReplace) {
        AlertDialog(
            onDismissRequest = { confirmReplace = false },
            title = { Text("Thay thế toàn bộ dữ liệu?") },
            text = { Text("Toàn bộ Gmail và máy ảo hiện tại sẽ bị xóa và thay bằng nội dung file sao lưu.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmReplace = false
                    importUri?.let { vm.importBackup(it, importPw, true) }
                }) { Text("Thay thế") }
            },
            dismissButton = { TextButton(onClick = { confirmReplace = false }) { Text("Hủy") } }
        )
    }
}
