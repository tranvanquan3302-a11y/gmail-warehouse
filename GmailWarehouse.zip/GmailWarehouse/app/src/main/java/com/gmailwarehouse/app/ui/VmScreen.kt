@file:OptIn(ExperimentalMaterial3Api::class)

package com.gmailwarehouse.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gmailwarehouse.app.AppViewModel
import com.gmailwarehouse.app.data.Status
import com.gmailwarehouse.app.data.VmEntity

@Composable
fun VmScreen(vm: AppViewModel) {
    val vms by vm.vms.collectAsState()
    val views by vm.views.collectAsState()
    val now by rememberNow()
    val accById = remember(views) { views.associateBy { it.acc.id } }
    val sorted = remember(vms) { vms.sortedWith { a, b -> naturalCompare(a.name, b.name) } }
    var showNew by remember { mutableStateOf(false) }
    var showBulk by remember { mutableStateOf(false) }
    var editTarget by remember { mutableStateOf<VmEntity?>(null) }
    var linkTarget by remember { mutableStateOf<VmEntity?>(null) }
    var deleteTarget by remember { mutableStateOf<VmEntity?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { showNew = true }, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Thêm máy ảo")
                }
                OutlinedButton(onClick = { showBulk = true }, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.Dns, null); Spacer(Modifier.width(6.dp)); Text("Tạo hàng loạt")
                }
            }
        }
        item {
            Text("Tổng: ${vms.size} máy ảo • ${vms.count { it.accountId != null }} đã liên kết Gmail",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (sorted.isEmpty()) {
            item { Text("Chưa có máy ảo. Bấm \"Thêm máy ảo\" hoặc \"Tạo hàng loạt\" (VD: VIP-1 đến VIP-7).",
                modifier = Modifier.padding(vertical = 24.dp)) }
        }
        items(sorted, key = { it.id }) { v ->
            val acc = v.accountId?.let { accById[it]?.acc }
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(v.name, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.weight(1f))
                        Switch(checked = v.active, onCheckedChange = { vm.setVmActive(v.id, it) })
                    }
                    InfoLine("Gmail", acc?.email ?: "Chưa liên kết")
                    InfoLine("Game", v.game.ifBlank { "—" })
                    InfoLine("Hoạt động", if (v.active) "Đang chạy" else "Tạm dừng")
                    InfoLine("Thời hạn", formatRemaining(v.expiresAt, now))
                    if (v.note.isNotBlank()) InfoLine("Ghi chú", v.note)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { linkTarget = v }, modifier = Modifier.weight(1.3f), contentPadding = PaddingValues(horizontal = 4.dp)) {
                            Text(if (acc == null) "Liên kết Gmail" else "Đổi Gmail", fontSize = 12.sp, maxLines = 1)
                        }
                        if (acc != null) {
                            OutlinedButton(onClick = { vm.unlinkVm(v.id) }, modifier = Modifier.weight(0.8f), contentPadding = PaddingValues(horizontal = 4.dp)) {
                                Text("Gỡ", fontSize = 12.sp, maxLines = 1)
                            }
                        }
                        OutlinedButton(onClick = { editTarget = v }, modifier = Modifier.weight(0.8f), contentPadding = PaddingValues(horizontal = 4.dp)) {
                            Text("Sửa", fontSize = 12.sp, maxLines = 1)
                        }
                        TextButton(onClick = { deleteTarget = v }, modifier = Modifier.weight(0.8f), contentPadding = PaddingValues(horizontal = 4.dp)) {
                            Text("Xóa", fontSize = 12.sp, maxLines = 1, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    if (showNew) VmEditDialog(vm, null) { showNew = false }
    editTarget?.let { t -> VmEditDialog(vm, t) { editTarget = null } }
    if (showBulk) BulkDialog(vm) { showBulk = false }
    linkTarget?.let { t -> LinkDialog(vm, t) { linkTarget = null } }
    deleteTarget?.let { t ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Xóa máy ảo ${t.name}?") },
            text = { Text("Gmail đang liên kết (nếu có) sẽ không bị xóa.") },
            confirmButton = { TextButton(onClick = { vm.deleteVm(t.id); deleteTarget = null }) { Text("Xóa") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Hủy") } }
        )
    }
}

@Composable
fun VmEditDialog(vm: AppViewModel, existing: VmEntity?, onDismiss: () -> Unit) {
    val rem = remember(existing?.id) { splitRemaining(existing?.expiresAt) }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var game by remember { mutableStateOf(existing?.game ?: "Rio Rise") }
    var active by remember { mutableStateOf(existing?.active ?: true) }
    var days by remember { mutableStateOf(rem.first) }
    var hours by remember { mutableStateOf(rem.second) }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Thêm máy ảo" else "Sửa máy ảo") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Tên máy ảo (VD: VIP-1)") }, singleLine = true)
                OutlinedTextField(game, { game = it }, label = { Text("Game đang chạy") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Đang hoạt động", modifier = Modifier.weight(1f)); Switch(active, { active = it })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(days, { days = it.filter(Char::isDigit) }, label = { Text("Ngày") }, singleLine = true,
                        modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(hours, { hours = it.filter(Char::isDigit) }, label = { Text("Giờ") }, singleLine = true,
                        modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                Text("Thời hạn còn lại. Để trống nếu không đặt.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(note, { note = it }, label = { Text("Ghi chú") }, minLines = 2)
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.saveVm(existing?.id, name, game, active, days, hours, note, onDismiss) }) { Text("Lưu") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}

@Composable
fun BulkDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    var prefix by remember { mutableStateOf("VIP-") }
    var start by remember { mutableStateOf("1") }
    var count by remember { mutableStateOf("7") }
    var game by remember { mutableStateOf("Rio Rise") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tạo máy ảo hàng loạt") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(prefix, { prefix = it }, label = { Text("Tiền tố tên") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(start, { start = it.filter(Char::isDigit) }, label = { Text("Bắt đầu từ") }, singleLine = true,
                        modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(count, { count = it.filter(Char::isDigit) }, label = { Text("Số lượng") }, singleLine = true,
                        modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                OutlinedTextField(game, { game = it }, label = { Text("Game (tùy chọn)") }, singleLine = true)
                Text("VD: VIP- từ 1, số lượng 7 → VIP-1 … VIP-7. Tên đã tồn tại sẽ được bỏ qua.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = { vm.addVmsBulk(prefix, start, count, game, onDismiss) }) { Text("Tạo") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}

@Composable
fun LinkDialog(vm: AppViewModel, target: VmEntity, onDismiss: () -> Unit) {
    val views by vm.views.collectAsState()
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Long?>(target.accountId) }
    var allowShared by remember { mutableStateOf(false) }
    val candidates = remember(views, search) {
        val s = search.trim().lowercase()
        views.filter { it.acc.status != Status.BANNED && (s.isEmpty() || it.acc.email.lowercase().contains(s)) }
            .sortedWith(accountComparator)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Liên kết Gmail với ${target.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(search, { search = it }, label = { Text("Tìm Gmail") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                LazyColumn(Modifier.heightIn(max = 260.dp)) {
                    items(candidates, key = { it.acc.id }) { c ->
                        Row(
                            Modifier.fillMaxWidth().clickable { selected = c.acc.id }.padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = selected == c.acc.id, onClick = { selected = c.acc.id })
                            Column {
                                Text(c.acc.email, fontSize = 14.sp)
                                val others = c.vms.filter { it.id != target.id }
                                Text(
                                    if (others.isEmpty()) Status.label(c.acc.status) else "Đang ở: " + others.joinToString { it.name },
                                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                if (candidates.isEmpty()) Text("Không có Gmail phù hợp.", fontSize = 12.sp)
                Row(Modifier.clickable { allowShared = !allowShared }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = allowShared, onCheckedChange = { allowShared = it })
                    Text("Cho phép Gmail đang gắn máy ảo khác dùng chung", fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = selected != null,
                onClick = { selected?.let { vm.linkVm(target.id, it, allowShared, onDismiss) } }
            ) { Text("Liên kết") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}
