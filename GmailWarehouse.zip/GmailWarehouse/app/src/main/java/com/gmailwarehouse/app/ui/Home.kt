@file:OptIn(ExperimentalMaterial3Api::class)

package com.gmailwarehouse.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.gmailwarehouse.app.AppViewModel
import com.gmailwarehouse.app.Screen
import com.gmailwarehouse.app.data.Status

@Composable
fun HomeScaffold(vm: AppViewModel) {
    val tabs = listOf(
        "Tổng quan" to Icons.Default.Home,
        "Chưa dùng" to Icons.Default.Email,
        "Đang dùng" to Icons.Default.CheckCircle,
        "Bị ban" to Icons.Default.Block,
        "Máy ảo" to Icons.Default.Smartphone
    )
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Gmail Warehouse", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                ),
                actions = {
                    IconButton(onClick = { vm.push(Screen.Settings) }) { Icon(Icons.Default.Settings, "Cài đặt") }
                    IconButton(onClick = { vm.lock() }) { Icon(Icons.Default.Lock, "Khóa kho") }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = vm.tab == i,
                        onClick = { vm.tab = i },
                        icon = { Icon(icon, label) },
                        label = { Text(label, fontSize = 11.sp, maxLines = 1) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (vm.tab in 1..3) {
                ExtendedFloatingActionButton(
                    onClick = { vm.push(Screen.Edit(null)) },
                    icon = { Icon(Icons.Default.Add, null) },
                    text = { Text("Thêm Gmail") }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (vm.tab) {
                0 -> AccountListScreen(vm, null, true)
                1 -> AccountListScreen(vm, Status.UNUSED, false)
                2 -> AccountListScreen(vm, Status.IN_USE, false)
                3 -> AccountListScreen(vm, Status.BANNED, false)
                else -> VmScreen(vm)
            }
        }
    }
}
