# proguard rules (minify tắt)
